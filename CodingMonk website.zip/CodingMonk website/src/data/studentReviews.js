import r1 from "../images/reviews/r1.jpeg";
import r2 from "../images/reviews/r2.jpeg";
import r3 from "../images/reviews/r3.jpeg";
import r4 from "../images/reviews/r4.jpeg";
import r5 from "../images/reviews/r5.jpeg";
import r6 from "../images/reviews/r6.jpeg";
import r7 from "../images/reviews/r7.jpeg";
import r8 from "../images/reviews/r8.jpeg";
import r9 from "../images/reviews/r9.jpeg";
import r10 from "../images/reviews/r10.jpeg";
import r11 from "../images/reviews/r11.jpeg";
import r12 from "../images/reviews/r12.jpeg";
import r13 from "../images/reviews/r13.jpeg";
import r14 from "../images/reviews/r14.jpeg";
import r15 from "../images/reviews/r15.jpeg";
export const REVIEWS = 
    [
        {
            id: 0,
            image: r1
        },
        {
            id: 1,
            image: r2
        },
        {
            id: 2,
            image: r3
        },{
            id: 3,
            image: r4
        },
        {
            id: 4,
            image: r5
        },
        {
            id: 5,
            image: r6
        },{
            id: 6,
            image: r7
        },
        {
            id: 7,
            image: r8
        },
        {
            id: 8,
            image: r9
        }
        ,
        {
            id: 9,
            image: r10
        },
        {
            id: 10,
            image: r11
        }
        ,
        {
            id: 11,
            image: r12
        }
        ,
        {
            id: 12,
            image: r13
        },
        {
            id: 13,
            image: r14
        }
        ,
        {
            id: 14,
            image: r15
        }
    ]