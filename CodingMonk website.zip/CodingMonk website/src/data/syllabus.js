export const SyllabusDetails = [
  {
    type : "Basic",
    id : 0,
    topics :  [
      {
        id: "0",
        title: " C++ STL",
        subtopics: ["Vector", "Map", "Stack","Queue","Pair","Set","Priority Queue"],
      },
      {
        id: "1",
        title: "Time Complexity and Space Complexity",
        subtopics: ["Asymptotic Notations", "Amortized Analysis"],
      },
      {
        id: "2",
        title: "Recursion",
        subtopics: ["On String","On Array","On Tree","On Linkedlist"],
      },
      {
        id: "3",
        title: "Backtracking",
        subtopics: ["Pruning In Backtracking Problems"],
      },
    ]
  },
  {
    type : "Intermediate",
    id : 1,
    topics :  [
      {
        id: 0,
        title: "Dynamic Programing",
        subtopics: ["Linear Dp", "String and Dp", "Dp with Tree and Graph","Knapsack based Dp","Dp with bits manipulation","Dp on math problems","Classical dp problems","Grid based dp","Multidimensional Dp","Digit problems with dp","Interval problems with dp"],
      },
      {
        id: 1,
        title: "Ad-hoc Technique",
        subtopics: ["Sliding Window", "Hashing", "2-Pointer"],
      },
      {
        id: 2,
        title: "Searching",
        subtopics: ["Binary Search", "Ternary Search", "Seaching in 2D array"],
      },
      {
        id: 3,
        title: "Greedy Technique",
        subtopics: ["Sort/Array", "Hash/Multi-set", "Strings","Heap","Stack"],
      },
    ]
  },
  {
    type : "Advanced",
    id : 2,
    topics :  [
      {
        id: 0,
        title: "Depth First Search",
        subtopics: ["On Tree", "On Graph"],
      },
      {
        id: 1,
        title: "Breadth First Search",
        subtopics: ["On Tree", "On Graph"],
      },
      {
        id: 2,
        title: "Graph Algorithms",
        subtopics: ["Union Find", "Cycle Find", "Graph Coloring /Bipartition","Topological Sort","Dijkstras and Bellman Ford","Finding Shortest Path","Tarjan’s Algorithm","Minimum Spanning Tree","Travelling Salesman Problem (TSP)","Kosaraju’s Algorithm"],
      },
      {
        id: 3,
        title: "Advanced DSA",
        subtopics: ["Trie","Segment Tree","AVL Tree"],
      },
    ]
  },
]


