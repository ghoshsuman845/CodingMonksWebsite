import vishal from '../images/team/vishal.jpeg'
import raja from '../images/team/raja.jpeg'
import tejeswi from '../images/team/tejaswi.jpeg'
import rahul from '../images/team/rahul.jpeg'
import yash from '../images/team/yash.jpg'
import ankita from '../images/team/ankita.jpeg'
import suman from '../images/team/suman.jpeg'


const FOUNDER=
[
    {
        id:0,
        name:"Vishal Singh",
        image:vishal,
        job:"SDE at cure.fit, Interned at Samsung R&D, Bangalore",
        linkedin:'https://www.linkedin.com/in/vishal-kumar-singh-312002157/'
    }
]

const WEBDEVELOPERS=
[
    {
        id:0,
        name:"Suman Ghosh",
        image:suman,
        job:"SDE at Navi, Ex-GFG",
        linkedin:'https://www.linkedin.com/in/ghoshsuman0129/'
    } 
]



const MENTORS=
[
    {
        id:0,
        name:"Rahul Kumar Mishra",
        image:rahul,
        job:"Upcoming SDE Intern at Oracle",
        linkedin:'https://www.linkedin.com/in/rahul-kumar-mishra-946852192/'
    },
    {
        id:1,
        name:"Ankita  Gupta",
        image:ankita,
        job:"Upcoming SDE at Visa",
        linkedin:'https://www.linkedin.com/in/ak566g'
    },{
        id:2,
        name:"Raja Reddy",
        image:raja,
        job:"Upcoming SDE intern at Chronus",
        linkedin:'https://www.linkedin.com/in/raja-reddy-pundra-650852196/'
    },
    {
        id:3,
        name:"Tejaswi Gupta",
        image:tejeswi,
        job:"Google Summer Of Code at The R Project for Statistical Computing",
        linkedin:'https://www.linkedin.com/in/tejasvi07/'
    },
    {
        id:4,
        name:"Yash Gupta",
        image:yash,
        job:"Upcoming SDE intern at Chronus",
        linkedin:'https://www.linkedin.com/in/yash-gupta-4a0ba5193/'
    }

]


export {FOUNDER,WEBDEVELOPERS,MENTORS};