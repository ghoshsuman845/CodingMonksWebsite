export const CoursePoints =
[
    {
        "image": "../images/course-pointers/best-seller.png",
        "description": "Top notch curriculum , designed by working professionals"
    },
    {
        "image": "../images/course-pointers/webinar.png",
        "description": "4 month course with interactive live classes"
    },
    {
        "image": "../images/course-pointers/query.png",
        "description": "Weekly contests and doubt solving sessions"
    },
    {
        "image": "../images/course-pointers/salary.png",
        "description": "Cheap and affordable price of just 500 rupees per month"
    }
]