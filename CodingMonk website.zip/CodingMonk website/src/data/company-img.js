export const CompanyImages =
[
    {
        "id": 1,
        "image": require("../images/companies/gs.png"),
    },
    {
        "id": 2,
        "image": require("../images/companies/amazon-9538.svg"),
    },
    {
        "id": 3,
        "image": require("../images/companies/curefit.png"),
    },
    {
        "id": 4,
        "image": require("../images/companies/adobe.jpg"),
    },
    {
        "id": 5,
        "image": require("../images/companies/qualcom.png"),
    },
    {
        "id": 6,
        "image": require("../images/companies/microsoft.svg"),
    },
    {
        "id": 7,
        "image": require("../images/companies/oracle-6.svg"),
    },
    {
        "id": 8,
        "image": require("../images/companies/samsung-9534.svg"),
    },
    {
        "id": 9,
        "image": require("../images/companies/jp-morgan.svg"),
    }
]