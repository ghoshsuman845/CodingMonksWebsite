import React from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import { AboutUs } from './aboutus';
import { CourseDetails } from './course-details';
import { HomePage } from './home-page';
import { FooterComponent } from './layouts/footer/footer';
import  {NavbarComponent}  from './layouts/navbar/navbar';
import { Layout , BackTop } from 'antd';
import './index.scss'

const { Header, Content, Footer, Sider } = Layout;

export const MainComponent = (props: any) => {
  return (
    <div className="main">
        <Layout className="main-layout">
            <Header className="header">
              <NavbarComponent />
            </Header>
            <Content>
            <Switch>
              <Route exact path="/home" component={HomePage} />
              <Route exact path="/course-details" component={CourseDetails} />
              <Route exact path="/about-us" component={AboutUs} />
              <Redirect to="/home" />
            </Switch>
            </Content>
            <Footer className="footer">
              <FooterComponent/>
            </Footer>
        </Layout>
        <BackTop />
      </div>
  );
};
