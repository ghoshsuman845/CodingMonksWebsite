import React from 'react';
import { AlumniCompanies } from './alumni-company';
import { Banner } from './banner';
import { CoursePointers } from './course-pointers';
import { EnrollBar } from './enroll-bar';
import './index.scss'
import { Testimonials } from './testimonials';

export const HomePage = (props: any) => {
  return (
       <>
         <Banner/>
         <AlumniCompanies/>
         <CoursePointers/>
         <EnrollBar/>
         <Testimonials/>
       </>
    );
};
