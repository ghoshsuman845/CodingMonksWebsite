import React from "react";
import { Row, Col, Typography , Button } from "antd";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";


const { Title } = Typography;

export const EnrollBar = (props: any) => {
  return (
    <div className="enroll-section" id="enroll-section">
      <div className="enroll">
        <section className="wrapper">
          <Title className="title">
            Enroll Now!
          </Title>
          <Title level={5} className="content">
            What are you waiting for? Enroll Now In Program Which Makes You Interview Ready.
          </Title>
          <Button className="btn" shape="round" href="https://t.me/joinchat/cguRAzNJSEs0Yjll">Apply Now</Button>
        </section>
      </div>
    </div>
  );
};
