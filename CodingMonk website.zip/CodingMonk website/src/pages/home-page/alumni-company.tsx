import React from "react";
import { Row, Col, Typography } from "antd";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";

import gs from "../../images/companies/gs.png";

import microsoft from "../../images/companies/microsoft.svg";
import oracle from "../../images/companies/oracle-6.svg";
import samsung from "../../images/companies/samsung-9534.svg";

import amazon from "../../images/companies/amazon-9538.svg";

const { Title } = Typography;

const options = {
  items: 4,
  loop: true,
  margin: 10,
  autoplay: true,
  autoplayspeed: 200,
  autoplayHoverPause: true,
};

export const AlumniCompanies = (props: any) => {
  //   const data = CompanyImages.map((item) => {
  //     return (
  //       <div className="item" key={item.id}>
  //           {item.id}
  //         <img src={`${item.image}`} alt="" />
  //       </div>
  //     );
  //   });
  return (
    <div className="company-section">
      <div className="company">
        <section className="wrapper">
          <Title className="title">
            Our students placed with Alumni Base at
          </Title>
          <OwlCarousel className="owl-theme owl-div" {...options}>
            <div className="item">
              <img src={gs} alt="" />
            </div>
            <div className="item">
              <img src={microsoft} alt="" />
            </div>
            <div className="item">
              <img src={amazon} alt="" />
            </div>
            <div className="item">
              <img src={samsung} alt="" />
            </div>
            <div className="item">
              <img src={oracle} alt="" />
            </div>
          </OwlCarousel>
        </section>
      </div>
    </div>
  );
};
