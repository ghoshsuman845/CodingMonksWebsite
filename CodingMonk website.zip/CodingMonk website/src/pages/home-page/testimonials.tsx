import { Typography, Carousel, Row, Col, Card, Avatar } from "antd";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { REVIEWS } from "../../data/studentReviews";

const { Title } = Typography;
const options = {
  items: 3,
  loop: true,
  margin: 10,
  autoplay: true,
  autoplayspeed: 200,
  autoplayHoverPause: true,
  responsiveClass:true,
  responsive:{
    0:{
        items:1,
        nav:true,
        dots: false
    },
    600:{
        items:3,
        nav:false
        
    }
}
};

export const Testimonials = (props: any) => {
  return (
    <div className="testimonials-section">
      <div className="testimonials">
        <section className="wrapper">
          <Title className="title">Our Top Success Stories</Title>
          <OwlCarousel className="owl-theme owl-div" {...options} >
            {REVIEWS.map((item) => {
              return (
                <Row
                  gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}
                  className="story-row"
                >
                  <Col className="gutter-row" key={item.id}>
                    <div className="item" >
                      <img src={item.image} alt="" />
                    </div>
                  </Col>
                </Row>
              );
            })}
          </OwlCarousel>
        </section>
      </div>
    </div>
  );
};

