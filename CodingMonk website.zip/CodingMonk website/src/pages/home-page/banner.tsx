import React from 'react';
import { Row, Col, Typography, Button} from 'antd';
import rightImg from '../../images/other-images/left-section-bg.png';
import waveImg from '../../images/other-images/wave.png';

const { Title } = Typography;

export const Banner = (props: any) => {
  return (
    <div className="banner-section">
      <div className="banner">
      <section className="banner-container">
        <div className="bubble x1"></div>
        <div className="bubble x2"></div>
        <div className="bubble x3"></div>
        <div className="bubble x4"></div>
        <div className="bubble x5"></div>
        <div className="bubble x6"></div>
        <div className="bubble x7"></div>
        <div className="bubble x8"></div>
        <div className="bubble x9"></div>
        <div className="bubble x10"></div>

        <Row className="wrapper">
          <Col xs={24} sm={24} md={24} lg={12} xl={10} className="left-sec">
            <Title className="title">Grab your dream job with <span className="spc">Codingmonks</span> Interview Ready Course</Title>

            <Button className="btn btn-1" shape="round" href="#course-section">Get Started</Button>
            <Button className="btn btn-2" shape="round" href="#enroll-section">Enroll Now</Button>
          </Col>
          <Col xs={24} sm={24} md={24} lg={12} xl={14}  className="right-sec">
            <img src={rightImg} alt="" />
          </Col>
        </Row>
      </section>
    </div>
    {/* <img src={waveImg} alt="wave-img" className="wave-img" /> */}

    </div>
  
  );
};
