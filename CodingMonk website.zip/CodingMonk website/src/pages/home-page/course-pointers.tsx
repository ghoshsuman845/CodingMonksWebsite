import React from 'react';
import { Row, Col, Typography ,  List, Avatar , Image} from 'antd';
import leftImg from '../../images/other-images/right-section.png';
import { CoursePoints } from '../../data/coursePagePoints';
import img1 from '../../images/course-pointers/best-seller.png';
import img2 from '../../images/course-pointers/webinar.png';
import img3 from '../../images/course-pointers/query.png';
import img4 from '../../images/course-pointers/salary.png';
import img5 from '../../images/course-pointers/meeting.png';

const { Title } = Typography;
 const data =
[
    {
        "image": img1,
        "description": "Top notch curriculum , designed by working professionals"
    },
    {
        "image": img2,
        "description": "4 month course with interactive live classes"
    },
    {
        "image":img3,
        "description": "Weekly contest and separate doubt solving session"
    },
    {
        "image": img4,
        "description": "Cheap and affordable price of just 1999/-"
    },
    {
      "image": img5,
      "description": "Free Mock Interview at end of the course"
    }
]

export const CoursePointers = (props: any) => {
  return (
    <div className="course-section" id="course-section">
      <div className="course-points">
      <section className="course-container">
          <Title className="title">Coding Monks Interview Ready Course</Title>
        <Row className="wrapper">
          <Col xs={24} sm={24} md={24} lg={12} xl={12} className="left-sec">
            <img src={leftImg} alt="" />
          </Col>
          <Col xs={24} sm={24} md={24} lg={12} xl={12}  className="right-sec">
          <List
          className="point-list"
            itemLayout="horizontal"
            dataSource={data}
            renderItem={item => (
              <List.Item className="list-item">
                <List.Item.Meta
                  avatar={<Avatar src={item.image} />}
                  title={item.description}
                />
              </List.Item>
            )}
          />
          </Col>
        </Row>
      </section>
    </div>
    </div>
  
  );
};
