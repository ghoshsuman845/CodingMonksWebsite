import React from "react";
import { Row, Col, Typography, List, Avatar, Collapse } from "antd";
import { CaretRightOutlined } from "@ant-design/icons";
import { SyllabusDetails } from "../../data/syllabus";
import "./index.scss";

const { Title } = Typography;
const { Panel } = Collapse;

export const Syllabus = (props: any) => {
  console.log(SyllabusDetails);

  const syllabus = SyllabusDetails.map((item) => {
    return (
        <div className="course-type col-7 col-md-4"  key={item.id}>
        <Title className="title">{item.type}</Title>
  
        <Collapse
          bordered={false}
          expandIcon={({ isActive }) => (
            <CaretRightOutlined rotate={isActive ? 90 : 0} />
          )}
          className="site-collapse-custom-collapse"
        >
          {item.topics.map((topic) => {
            return (
              <Panel
                header={topic.title}
                key={topic.id}
                className="site-collapse-custom-panel"
              >
                <ol className="subtopics">
                  {topic.subtopics.map((sub) => {
                    return (
                        <li>{sub}</li>
                    )
                  })}
                </ol>
              </Panel>
            );
          })}
        </Collapse>
      </div>
    )
  });



  return (
    <div className="course-details">
      <section className="syllabus">
        <Title className="title">Syllabus</Title>
        <div className="details-row row">
          {syllabus}
        </div>
      </section>
    </div>
  );
};
