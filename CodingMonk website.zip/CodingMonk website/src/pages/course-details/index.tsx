import React from "react";
import "./index.scss";
import { CourseProvides } from "./course-provides";
import { Syllabus } from "./syllabus";



export const CourseDetails = (props: any) => {

  return (
    <div className="course-details">
       <CourseProvides/>
       <Syllabus/>
    </div>
  );
};
