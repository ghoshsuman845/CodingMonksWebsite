import { Row, Col, Typography, List, Avatar } from "antd";
import leftImg from "../../images/other-images/programmer.jpg";
import img1 from "../../images/course-pointers/best-seller.png";
import img2 from "../../images/course-pointers/webinar.png";
import img3 from "../../images/course-pointers/query.png";
import "./index.scss";

const { Title } = Typography;

const data = [
  {
    img: img1,
    desc: "Complete DSA to ace Interviews at top tech companies",
  },
  {
    img: img2,
    desc: "4- month course with Live class and Doubt sessions",
  },
  {
    img: img3,
    desc: "Everyweek problem solving with leetcode",
  },
];

export const CourseProvides = () => {


  return (
    <div className="course-details">
      <section className="course-points">
          <Title className="title">CodingMonk provides you:</Title>
          <Row className="wrapper">
            <Col xs={24} sm={24} md={24} lg={12} xl={12} className="left-sec">
              <img src={leftImg} alt="programmer" />
            </Col>
            <Col xs={24} sm={24} md={24} lg={12} xl={12} className="right-sec">
              <List
                className="point-list"
                itemLayout="horizontal"
                dataSource={data}
                renderItem={(item) => (
                  <List.Item className="list-item">
                    <List.Item.Meta
                      avatar={<Avatar src={item.img} />}
                      title={item.desc}
                    />
                  </List.Item>
                )}
              />
            </Col>
          </Row>
        </section>
    </div>
  );
};
