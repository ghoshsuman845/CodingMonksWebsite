import React from 'react';
import { Button, Layout, Typography } from 'antd';
import { FacebookFilled, LinkedinFilled, MailFilled } from '@ant-design/icons';
import logo from '../../../images/other-images/logo.png';

const { Footer } = Layout;
const { Title } = Typography;


export const FooterComponent = (props: any) => {
  return (
    <div className="footer-section">
    <div className="footer">
      <section className="wrapper">
        <Title className="title">
          <img src={logo} alt="logo" />
          Contact Us
        </Title>
        <Title level={5} className="content">
        Just starting out on your coding journey? No Worries!
        We have professionals from top companies from around the globe to help you make Interview Ready
        </Title>
        {/* <div className="social-links">
          <Button className="btn" shape="circle" icon={<LinkedinFilled />} />
          <Button className="btn" shape="circle" icon={<MailFilled />} />
          <Button className="btn" shape="circle" icon={<FacebookFilled />} />

        </div> */}
      </section>
    </div>
  </div>
  );
};
