import {
  Nav,
  Navbar,
  NavbarBrand,
  NavbarToggler,
  Collapse,
  NavItem,
} from "reactstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { NavLink } from "react-router-dom";
import React, { useState } from "react";
import logo from "../../../images/other-images/logo.png";
import "../../layouts/index.scss";

export const NavbarComponent = (props: any) => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const toggleNav = () => {
    setIsNavOpen(!isNavOpen);
  };

  return (
    <div className="navbar">
      <Navbar dark fixed="top" expand="md">
        <div className="container-fluid row" style={{ justifyContent: "left" }}>
          <NavbarToggler className="col-1" onClick={() => toggleNav()} />
          <NavbarBrand
            className="col-8 col-sm-6 col-md-4 col-lg-3 d-flex align-items-center"
            href="/"
          >
            <img src={logo} alt="logo" width="70px" />
            <span className="title">Coding Monks</span>
          </NavbarBrand>
          <Collapse
            className="col-5 justify-content-end"
            isOpen={isNavOpen}
            navbar
          >
            <Nav navbar className="nav">
              <NavItem>
                <NavLink className="nav-link" to="/home" onClick={() => toggleNav()} >
                  {" "}
                  Home
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink className="nav-link" to="/course-details" onClick={() => toggleNav()}>
                  Course
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink className="nav-link" to="/about-us" onClick={() => toggleNav()}>
                  About Us
                </NavLink>
              </NavItem>
            </Nav>
          </Collapse>
        </div>
      </Navbar>
    </div>
  );
};
