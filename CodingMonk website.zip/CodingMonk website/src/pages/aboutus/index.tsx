import { Card, Avatar, Typography, Row, Col, Button } from "antd";
import {
  LinkedinFilled,
  MailFilled,
  MediumSquareFilled,
} from "@ant-design/icons";
import "./index.scss";
import { FOUNDER, WEBDEVELOPERS, MENTORS } from "../../data/about-us";

const { Meta } = Card;
const { Title } = Typography;

export const AboutUs = (props: any) => {
  const founder = FOUNDER.map((founder) => {
    return (
      <Card
        className="card"
        hoverable
        actions={[
          <Button type="link" href={founder.linkedin}>
            <LinkedinFilled key="linkedin" />
          </Button>
          
        ]}
      >
        <Meta
          className="meta"
          key={founder.id}
          avatar={<Avatar src={founder.image} />}
          title={founder.name}
          description={founder.job}
        />
      </Card>
    );
  });

  const team = WEBDEVELOPERS.map((team) => {
    return (
      <Col className="gutter-row colm" xs={{ span: 24 }} sm={{ span: 12 }} md={{ span: 8 }} lg={{ span: 8 }}>
        <div className="devs-cards">
          <Card
            className="card"
            hoverable
            actions={[
              <Button type="link" href={team.linkedin}>
                <LinkedinFilled key="linkedin" />
              </Button>,
              
            ]}
          >
            <Meta
              className="meta"
              key={team.id}
              avatar={<Avatar src={team.image} />}
              title={team.name}
              description={team.job}
            />
          </Card>
        </div>
      </Col>
    );
  });

  const mentors = MENTORS.map((mentor) => {
    return (
      <Col className="gutter-row colm"  xs={{ span: 24 }} sm={{ order: 12 }} md={{ order: 8 }} lg={{ order: 8 }}>
        <div className="devs-cards">
          <Card
            className="card"
            hoverable
            actions={[
              <Button type="link" href={mentor.linkedin}>
                <LinkedinFilled key="linkedin" />
              </Button>,
              
            ]}
          >
            <Meta
              className="meta"
              key={mentor.id}
              avatar={<Avatar src={mentor.image} />}
              title={mentor.name}
              description={mentor.job}
            />
          </Card>
        </div>
      </Col>
    );
  });

  return (
    <div className="about-us">
      <div className="wrapper">
        <div className="triangle"></div>
        <div className="founder">
          <Title className="title">Founder</Title>
          <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }} className="team-data">{founder}</Row>
        </div>
        <div className="instrctors">
          <Title className="title">Mentors</Title>
          <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }} className="team-data">{mentors}</Row>
        </div>
        <div className="dev-team">
          <Title className="title">Development Team</Title>
          <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }} className="team-data">{team}</Row>
        </div>
       
      </div>
    </div>
  );
};
